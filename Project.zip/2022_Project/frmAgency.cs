﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class frmAgency : Form
    {
        public frmAgency()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtAgencyName.Text) || (!Regex.IsMatch(txtAgencyName.Text, @"^[A-Z][a-z ']+$")))
            {
                errAgencyName.SetError(txtAgencyName, " Please enter agency name");
                validate = false;

            }
            else
            {
                validate = true;
            }
            if (validate)
            {
                Agency agency = new Agency();
                agency.AgencyName = txtAgencyName.Text;
                agency.SurbubID = int.Parse(cmbSurbubID.SelectedValue.ToString());

                int x = bll.InsertAgency(agency);
                if (x > 0)
                {
                    MessageBox.Show("Added");
                }
            }
            
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvAgency.DataSource = bll.DisplayAgency();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Agency agency = new Agency();
            agency.AgencyID = int.Parse(txtAgencyID.Text);

            int x = bll.DeleteAgency(agency);   
            if (x > 0)

            {
                MessageBox.Show("Deleted");
            }
        }

        private void frmAgency_Load(object sender, EventArgs e)
        {
            txtAgencyID.Enabled = false;    
            cmbSurbubID.DataSource = bll.LoadcmbSurbub();
            cmbSurbubID.DisplayMember = "SurbubDescription";
            cmbSurbubID.ValueMember = "SurbubID";
        }

        private void dgvAgency_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dgvAgency.SelectedRows.Count > 0)
            {
                txtAgencyID.Text = dgvAgency.SelectedRows[0].Cells["AgencyID"].Value.ToString();
                txtAgencyName.Text = dgvAgency.SelectedRows[0].Cells["AgencyName"].Value.ToString();
                
            }
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmMenuAdmin frmMenuAdmin = new frmMenuAdmin();
            frmMenuAdmin.Show();
            this.Hide();
        }
    }
}
