﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class frmSurbub : Form
    {
        public frmSurbub()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtSurbubDesc.Text) || (!Regex.IsMatch(txtSurbubDesc.Text, @"^[A-Z][a-z']+$")))
            {
                errCode.SetError(txtSurbubDesc, " Please enter surbub name");
                validate = false;
            }
            if (string.IsNullOrEmpty(txtPostalCode.Text) || (!Regex.IsMatch(txtPostalCode.Text, @"^$|^[0-9X]{4}$")))
            {
                errCode.SetError(txtPostalCode, " Please enter postal code");
                validate = false;

            }
            else
            {
                validate = true;
            }
            if(validate)
            {
                Surbub surbub = new Surbub();
                surbub.SurbubDescription = txtSurbubDesc.Text;
                surbub.PostalCode = int.Parse(txtPostalCode.Text);
                surbub.CityID = int.Parse(cmbCityID.SelectedValue.ToString());

                int x = bll.InsertSurbub(surbub);
                if (x > 0)
                {
                    MessageBox.Show(x + " Added");
                }
            }
           
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvSurbub.DataSource = bll.DisplaySurbub();
        }

        private void frmSurbub_Load(object sender, EventArgs e)
        {
            txtSurbubID.Enabled = false;
            cmbCityID.DataSource = bll.LoadcmbCity();
            cmbCityID.DisplayMember = "CityDescription";
            cmbCityID.ValueMember = "CityID";
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmMenuAdmin frmMenuAdmin = new frmMenuAdmin();
            frmMenuAdmin.Show();
            this.Hide();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            frmCity city = new frmCity();
            city.Show();
            this.Hide();
        }
    }
}
