﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace _2022_Project
{
    public partial class frmAgentLogin : Form
    {
        public frmAgentLogin()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();  

        private void btnLogin_Click(object sender, EventArgs e)
        {
            DataTable dt = bll.GetAgentLogin(txtAgentEmail.Text, txtAgentPassword.Text);

            if (dt.Rows.Count > 0)
            {
                frmAgentMenu agent = new frmAgentMenu();
                agent.Show();
                this.Hide();
            }
            else
            {
                txtAgentEmail.Clear();
                txtAgentPassword.Clear();
                lblWrong.Visible = true;
            }
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
        private void frmAgentLogin_Load(object sender, EventArgs e)
        {
            lblWrong.Visible = false;
        }
    }
    
}
