﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace _2022_Project
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnAdd_Click(object sender, EventArgs e)
        {
             Administrator admin = new Administrator();

            admin.Name = txtName.Text;
            admin.Surname = txtSurname.Text;
            admin.Email = txtEmail.Text;
            admin.Password = txtPassword.Text;
            admin.Status = cmbStatus.Text;
            int x = bll.InsertAdmin(admin);
            if(x > 0)
            {
                MessageBox.Show("added!");
            }
        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {
            txtAdminID.Enabled = false;
            cmbStatus.Items.Add("Single");
            cmbStatus.Items.Add("Married");
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvAdmin.DataSource = bll.DisplayAdmin();
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmMenuAdmin frmMenuAdmin = new frmMenuAdmin();
            frmMenuAdmin.Show();
            this.Hide();
        }
    }
}
