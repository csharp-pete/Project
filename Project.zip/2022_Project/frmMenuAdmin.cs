﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2022_Project
{
    public partial class frmMenuAdmin : Form
    {
        public frmMenuAdmin()
        {
            InitializeComponent();
        }

        private void btnProperties_Click(object sender, EventArgs e)
        {
            Form1 property = new Form1();
            property.Show();
            this.Hide();
        }

        private void btnPropertyTypes_Click(object sender, EventArgs e)
        {
            frmPropertyType type = new frmPropertyType();
            type.Show();
            this.Hide();
        }

        private void btnLocation_Click(object sender, EventArgs e)
        {
            frmSurbub surbub = new frmSurbub(); 
            surbub.Show();
            this.Hide();
        }

        private void btnAgencies_Click(object sender, EventArgs e)
        {
            frmAgency agency = new frmAgency();
            agency.Show();
            this.Hide();
        }

        private void btnAgents_Click(object sender, EventArgs e)
        {
            frmPropertyAgent agencies = new frmPropertyAgent();
            agencies.Show();
            this.Hide();
        }

        private void btnAddAdmin_Click(object sender, EventArgs e)
        {
            frmAdmin addAdmin = new frmAdmin();
            addAdmin.Show();
            this.Hide();
        }

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}
