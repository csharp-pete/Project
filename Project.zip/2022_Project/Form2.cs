﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace _2022_Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
           
            //DataTable dt = bll.Logins(txtEmail.Text, txtPassword.Text);
            //string role = dt.Rows[0]["RoleDesc"].ToString();
            //if (dt.Rows.Count > 0)
            //{
            //    if(role == "Admin")
            //    {
            //        frmMenuAdmin admin = new frmMenuAdmin();
            //        admin.Show();
            //        this.Hide();
            //    }
            //    else if (role == "Agent")
            //    {
            //        frmMenuAgent gent = new frmMenuAgent();
            //        gent.Show();
            //        this.Hide();
            //    }
            //}
            // if(dt.Rows.Count ==  0) 
            //{
            //    txtEmail.Clear();
            //    txtPassword.Clear();

            //}
        }
    }
}
