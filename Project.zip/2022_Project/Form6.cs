﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void Form6_Load(object sender, EventArgs e)
        {
            txtCityID.Enabled = false;

            cmbProvince.DataSource = bll.LoadcmbProvince();
            cmbProvince.DisplayMember = "Description";
            cmbProvince.ValueMember = "ProvinceID";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtCityDescription.Text) || (!Regex.IsMatch(txtCityDescription.Text, @"^[A-Z][a-z ']+$")))
            {
                errCityDesc.SetError(txtCityDescription, " Please enter city name correctly");
                validate = false;
            }
            else
            {
                validate = true;
            }
            if (validate)
            {
                City c = new City();
                c.CityDescription = txtCityDescription.Text;
                c.ProvinceID = int.Parse(cmbProvince.SelectedValue.ToString());
                int x = bll.InsertCity(c);
                if (x > 0)
                {
                    MessageBox.Show("Added.");
                }
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvCity.DataSource = bll.DisplayCity();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            frmProv prov = new frmProv();
            prov.Show();
            this.Hide();
        }
    }
}
