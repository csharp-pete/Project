﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2022_Project
{
    public partial class frmAgentMenu : Form
    {
        public frmAgentMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmProperties properties = new frmProperties(); 
            properties.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmRental rental = new frmRental();
            rental.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}
