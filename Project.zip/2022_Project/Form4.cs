﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtProvinceDesc.Text) || (!Regex.IsMatch(txtProvinceDesc.Text, @"^[A-Z][a-z ']+$")))
            {
                errProvince.SetError(txtProvinceDesc, " Please enter province");
                validate = false;

            }
            else
            {
                validate = true;
            }
            if (validate)
            {
                Province p = new Province();
                p.Description = txtProvinceDesc.Text;
                int x = bll.InsertProvince(p);
                if (x > 0)
                {
                    MessageBox.Show(x + " Added");
                }
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvProvince.DataSource = bll.DisplayProvince();
        }
    }
}
