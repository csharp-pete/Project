﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2022_Project
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void btnAdminLogin_Click(object sender, EventArgs e)
        {
            frmAdminLogin admin = new frmAdminLogin();
            admin.Show();
            this.Hide();
        }

        private void btnAgentLogin_Click(object sender, EventArgs e)
        {
            frmAgentLogin login = new frmAgentLogin();
            login.Show();
            this.Hide();
        }

        private void btnTenantLogin_Click(object sender, EventArgs e)
        {
            frmTenantLogin login = new frmTenantLogin();
            login.Show();
            this.Hide();
        }
    }
}
