﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace _2022_Project
{
    public partial class frmAgentReport : Form
    {
        public frmAgentReport()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void frmAgentReport_Load(object sender, EventArgs e)
        {
           // dgvAgentReport.DataSource = bll.GetAgentReport();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dgvAgentReport.DataSource = bll.GetAgentReport(txtDesc.Text,dtaStart.Text, dtaEnd.Text);
        }
    }
}
