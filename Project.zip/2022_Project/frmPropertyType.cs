﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class frmPropertyType : Form
    {
        public frmPropertyType()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtPropertyTypeDesc.Text) || (!Regex.IsMatch(txtPropertyTypeDesc.Text, @"^[A-Z][a-z ']+$")))
            {
                errPropertyType.SetError(txtPropertyTypeDesc, " Please enter property type description");
                validate = false;

            }
            else
            {
                validate = true;
            }
            if (validate)
            {
                PropertyType propType = new PropertyType();

                propType.PropertyTypeDesc = txtPropertyTypeDesc.Text;
                int x = bll.InsertPropertyType(propType);
                if (x > 0)
                {
                    MessageBox.Show(x + "Added");
                }
            }
            
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvPropertyType.DataSource = bll.DisplayPropertyType();
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmMenuAdmin frmAdmin = new frmMenuAdmin();
            frmAdmin.Show();
            this.Hide();
        }
    }
}
