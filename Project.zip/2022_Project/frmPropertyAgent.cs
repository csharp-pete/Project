﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace _2022_Project
{
    public partial class frmPropertyAgent : Form
    {
        public frmPropertyAgent()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void frmPropertyAgent_Load(object sender, EventArgs e)
        {
            txtPropertyAgentID.Enabled = false;
            cmbAgent.DataSource = bll.LoadAgent();
            cmbAgent.DisplayMember =  "FullName";
            cmbAgent.ValueMember = "AgentID";

            cmbPropertyID.DataSource = bll.LoadcmbProperty();
            cmbPropertyID.DisplayMember = "Description";
            cmbPropertyID.ValueMember = "PropertyID";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            PropertyAgent pagent = new PropertyAgent();
            pagent.PropertyID = int.Parse(cmbPropertyID.SelectedValue.ToString());
            pagent.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            pagent.Date = dtaDate.Text; 
            int x = bll.InsertPropertyAgent(pagent);
            if(x > 0)
            {
                MessageBox.Show("Added");
            }

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvPropertyAgent.DataSource = bll.DisplayPropertyAgent();
        }

        private void dgvPropertyAgent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dgvPropertyAgent.Rows.Count > 0)
            {
                txtPropertyAgentID.Text = dgvPropertyAgent.Rows[0].Cells["PropertyAgentID"].Value.ToString();
                cmbAgent.Text = dgvPropertyAgent.Rows[0].Cells["FullName"].Value.ToString();
                cmbPropertyID.Text = dgvPropertyAgent.Rows[0].Cells["Description"].Value.ToString();
                dtaDate.Text = dgvPropertyAgent.Rows[0].Cells["Date"].Value.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            PropertyAgent pagent = new PropertyAgent();
            pagent.PropertyAgentID = int.Parse(txtPropertyAgentID.Text);
            pagent.PropertyID = int.Parse(cmbPropertyID.SelectedValue.ToString());
            pagent.AgentID = int.Parse(cmbAgent.SelectedValue.ToString());
            pagent.Date = dtaDate.Text;
            int x = bll.UpdatePropertyAgent(pagent);
            if (x > 0)
            {
                MessageBox.Show("Updated");
            }
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmMenuAdmin frmMenuAdmin= new frmMenuAdmin();
            frmMenuAdmin.Show();
            this.Hide();
        }
    }
}
