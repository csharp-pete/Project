﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void Form5_Load(object sender, EventArgs e)
        {
            txtSurbubID.Enabled = false;
            cmbCityID.DataSource = bll.LoadcmbCity();
            cmbCityID.DisplayMember = "CityDescription";
            cmbCityID.ValueMember = "CityID";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtSurbubDesc.Text) || (!Regex.IsMatch(txtSurbubDesc.Text, @"^[A-Z][a-z']+$")))
            {
                errCode.SetError(txtSurbubDesc, " Please enter surbub name");
                validate = false;
            }
            if (string.IsNullOrEmpty(txtPostalCode.Text) || (!Regex.IsMatch(txtPostalCode.Text, @"^$|^[0-9X]{4}$")))
            {
                errCode.SetError(txtPostalCode, " Please enter postal code");
                validate = false;

            }
            else
            {
                validate = true;
            }
            if (validate)
            {
                Surbub surbub = new Surbub();
                surbub.SurbubDescription = txtSurbubDesc.Text;
                surbub.PostalCode = int.Parse(txtPostalCode.Text);
                surbub.CityID = int.Parse(cmbCityID.SelectedValue.ToString());

                int x = bll.InsertSurbub(surbub);
                if (x > 0)
                {
                    MessageBox.Show(x + " Added");
                }
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvSurbub.DataSource = bll.DisplaySurbub();
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Form6 form = new Form6();
            form.Show();
            this.Hide();
        }
    }
}
