﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.IO;

namespace _2022_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();  
        private void cmbSuburbID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtPropertyID.Enabled = false;
            cmbSuburbID.DataSource = bll.LoadcmbSurbub();
            cmbSuburbID.DisplayMember = "SurbubDescription";
            cmbSuburbID.ValueMember = "SurbubID";
            cmbPropertyTypeID.DataSource = bll.LoadPropertyType();
            cmbPropertyTypeID.DisplayMember = "PropertyTypeDescription";
            cmbPropertyTypeID.ValueMember = "PropertyTypeID";

            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add("Unvailable");
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Open Image";
            ofd.Filter = "Image Files(*.JPG;*.PNG;.GIF)|*.JPG;*.PNG;.GIF";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ptbProperty.Image = Image.FromFile(ofd.FileName);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Image img = ptbProperty.Image;
            byte[] arr;
            ImageConverter converter = new ImageConverter();
            arr = (byte[])converter.ConvertTo(img, typeof(byte[]));
            Property property = new Property();
            property.Description = txtDescription.Text;
            property.Price =  double.Parse(txtPrice.Text);
            property.Image = arr;
            property.PropertyTypeID = int.Parse(cmbPropertyTypeID.SelectedValue.ToString());
            property.Status = cmbStatus.SelectedItem.ToString();
            property.SurbubID = int.Parse(cmbSuburbID.SelectedValue.ToString()) ;
            int x = bll.InsertProperty(property);
            if (x> 0)
            {
                MessageBox.Show("Added");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvProperty.DataSource = bll.DisplayProperty();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Property property = new Property();
            property.PropertyID = int.Parse(txtPropertyID.Text);
            property.Price = double.Parse(txtPrice.Text);
            
            property.PropertyTypeID = int.Parse(cmbPropertyTypeID.SelectedValue.ToString());
            property.Status = cmbStatus.SelectedItem.ToString();
            
            int x = bll.UpdateProperty(property);
            if (x > 0)
            {
                MessageBox.Show("Updaded");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Property property = new Property();
            property.PropertyID = int.Parse(txtPropertyID.Text);
            int x = bll.DeleteProperty(property);
            if (x > 0)
            {
                MessageBox.Show("Deleted");
            }
        }

        private void dgvProperty_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dgvProperty.SelectedRows.Count > 0)
            {
                txtPropertyID.Text = dgvProperty.SelectedRows[0].Cells["PropertyID"].Value.ToString();
                txtDescription.Text = dgvProperty.SelectedRows[0].Cells["Description"].Value.ToString();
                txtPrice.Text = dgvProperty.SelectedRows[0].Cells["Price"].Value.ToString();
                cmbPropertyTypeID.Text = dgvProperty.SelectedRows[0].Cells["PropertyTypeDescription"].Value.ToString();
                cmbStatus.Text = dgvProperty.SelectedRows[0].Cells["Status"].Value.ToString();
                cmbSuburbID.Text = dgvProperty.SelectedRows[0].Cells["SurbubDescription"].Value.ToString();
                byte[] imgData = (byte[])dgvProperty.CurrentRow.Cells[3].Value;
                MemoryStream ms = new MemoryStream(imgData);
                ptbProperty.Image = Image.FromStream(ms);
            }
        }

        private void btnGoback_Click(object sender, EventArgs e)
        {
            
            frmMenuAdmin frmMenuAdmin = new frmMenuAdmin();
            frmMenuAdmin.Show();
            this.Hide();
        }
    }
}
