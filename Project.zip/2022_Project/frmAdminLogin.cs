﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace _2022_Project
{
    public partial class frmAdminLogin : Form
    {
        public frmAdminLogin()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnLogin_Click(object sender, EventArgs e)
        {
            DataTable dt = bll.GetAdminLogin(txtEmail.Text, txtPassword.Text);
            
            if(dt.Rows.Count > 0)
            {
                frmMenuAdmin admin = new frmMenuAdmin();
                admin.Show();
                this.Hide();
            }
            else
            {
                txtEmail.Clear();
                txtPassword.Clear();
                lblWrong.Visible = true;
            }
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void frmAdminLogin_Load(object sender, EventArgs e)
        {
            lblWrong.Visible = false;
        }
    }
}
