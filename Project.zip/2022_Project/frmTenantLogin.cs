﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace _2022_Project
{
    public partial class frmTenantLogin : Form
    {
        public frmTenantLogin()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnLogin_Click(object sender, EventArgs e)
        {
            DataTable dt = bll.GetTenantLogin(txtTenantEmail.Text, txtTenantPassword.Text);

            if (dt.Rows.Count > 0)
            {
                Form3 f = new Form3();  
                f.Show();
                this.Hide();
            }
            else
            {
                txtTenantEmail.Clear();
                txtTenantPassword.Clear();
                lblWrong.Visible = true;
            }
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }

        private void frmTenantLogin_Load(object sender, EventArgs e)
        {
            lblWrong.Visible = false;
        }
    }
}
