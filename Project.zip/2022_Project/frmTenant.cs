﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class frmTenant : Form
    {
        public frmTenant()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtName.Text) || (!Regex.IsMatch(txtName.Text, @"^[A-Z][a-z']+$")))
            {
                errName.SetError(txtName," Please enter name");
                validate = false;
                
            }
            else if (string.IsNullOrEmpty(txtSurname.Text) || (!Regex.IsMatch(txtSurname.Text, @"^[A-Z][a-z']+$")))
            {
                errName.SetError(txtSurname, "Please enter surname");
                validate = false;
            }
            else if (string.IsNullOrEmpty(txtEmail.Text) || (!Regex.IsMatch(txtEmail.Text, @"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$")))
            {
                errName.SetError(txtEmail, " Please enter email format");
                validate = false;
            }
            else if (string.IsNullOrEmpty(txtPhone.Text) || (!Regex.IsMatch(txtPhone.Text, @"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}?")))
            {
                errName.SetError(txtPhone, "please enter the correct number");
                validate = false;
            }
            else if(string.IsNullOrEmpty (txtPassword.Text) || (!Regex.IsMatch(txtPassword.Text,@"((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W)\w.{5,10}\w)")))
            {
                errName.SetError(txtPassword, "Enter correct password format");
                validate = false;
            }
            else 
            {
                validate = true;
            }
            if (validate)
            {

                Tenant tenant = new Tenant();
                tenant.TenantSurname = txtName.Text;
                tenant.TenantName = txtSurname.Text;
                tenant.TenantEmail = txtEmail.Text;
                tenant.Password = txtPassword.Text;
                tenant.Phone = int.Parse(txtPhone.Text);
                tenant.Status = cmbStatus.Text;

                int x = bll.InsertTenant(tenant);
                if (x > 0)
                {
                    MessageBox.Show("Added");
                }
            }

            else
            {

            }





        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvTenant.DataSource = bll.DisplayTenant();
        }

        private void dgvTenant_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dgvTenant.SelectedRows.Count > 0)
            {
                txtTenantID.Text = dgvTenant.SelectedRows[0].Cells["TenantID"].Value.ToString();
                txtName.Text = dgvTenant.SelectedRows[0].Cells["Name"].Value.ToString();
                txtSurname.Text = dgvTenant.SelectedRows[0].Cells["Surname"].Value.ToString();
                txtEmail.Text = dgvTenant.SelectedRows[0].Cells["Email"].Value.ToString();
                txtPassword.Text = dgvTenant.SelectedRows[0].Cells["Password"].Value.ToString();
                txtPhone.Text = dgvTenant.SelectedRows[0].Cells["Phone"].Value.ToString();
                cmbStatus.Text = dgvTenant.SelectedRows[0].Cells["Status"].Value.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Tenant tenant = new Tenant();
            tenant.TenantID = int.Parse(txtTenantID.Text);
            tenant.TenantEmail = txtEmail.Text;
            tenant.Status = cmbStatus.Text;
            int x = bll.UpdateTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show("Updated");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Tenant tenant = new Tenant();
            tenant.TenantID = int.Parse(txtTenantID.Text);
            int x = bll.DeleteTenant(tenant);
            if (x > 0)
            {
                MessageBox.Show("Deleted");
            }
        }

        private void frmTenant_Load(object sender, EventArgs e)
        {
            txtTenantID.Enabled = false;
            cmbStatus.Items.Add("Single");
            cmbStatus.Items.Add("Married");
        }
    }
}
