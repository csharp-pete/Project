﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Text.RegularExpressions;

namespace _2022_Project
{
    public partial class frmAgent : Form
    {
        public frmAgent()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool validate = false;
            if (string.IsNullOrEmpty(txtName.Text) || (!Regex.IsMatch(txtName.Text, @"^[A-Z][a-z']+$")))
            {
                errAgentName.SetError(txtName, " Please enter agent name");
                validate = false;

            }
            else if (string.IsNullOrEmpty(txtSurname.Text) || (!Regex.IsMatch(txtSurname.Text, @"^[A-Z][a-z']+$")))
            {
                errAgentName.SetError(txtSurname, " Please enter agent surname");
                validate = false;
            }
            else if(string.IsNullOrEmpty(txtEmail.Text) || (!Regex.IsMatch(txtEmail.Text, @"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$")))
            {
                errAgentName.SetError(txtEmail, " Please enter agent email");
                validate = false;
            }
            else if(string.IsNullOrEmpty(txtPassword.Text) || (!Regex.IsMatch(txtPassword.Text, @"((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W)\w.{5,10}\w)")))
            {
                errAgentName.SetError(txtPassword, " Please enter agent password format");
                validate = false;
            }
            else if(string.IsNullOrEmpty(txtPhone.Text) || (!Regex.IsMatch(txtPhone.Text, @"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}?")))
            {
                errAgentName.SetError(txtPhone, " Please enter agent phone format");
                validate = false;
            }
            else
            {
                validate = true;
            }
            if (validate)
            {
                Agent agent = new Agent();
                agent.AgentSurname = txtName.Text;
                agent.AgentName = txtSurname.Text;
                agent.AgentEmail = txtEmail.Text;
                agent.Password = txtPassword.Text;
                agent.Phone = int.Parse(txtPhone.Text);
                agent.Status = cmbStatus.Text;
                agent.AgencyID = int.Parse(cmbAgencyID.SelectedValue.ToString());
                int x = bll.InsertAgent(agent);
                if (x > 0)
                {
                    MessageBox.Show("Added");
                }
            }
           
        }

        private void frmAgent_Load(object sender, EventArgs e)
        {
            txtAgentID.Enabled = false;

            cmbStatus.Items.Add("Available");
            cmbStatus.Items.Add("Not Available");

            cmbAgencyID.DataSource = bll.LoadcmbAgency();
            cmbAgencyID.DisplayMember = "AgencyName";
            cmbAgencyID.ValueMember = "AgencyID";
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvAgent.DataSource = bll.DisplayAgent();
        }

        private void dgvAgent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Agent agent = new Agent();
            agent.AgentID = int.Parse(txtAgentID.Text);
            agent.Phone = int.Parse(txtPhone.Text);
            agent.AgentEmail = txtEmail.Text;
            agent.Status = cmbStatus.Text;
            int x = bll.UpdateAgent(agent);
            if (x > 0)
            {
                MessageBox.Show("Updated");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Agent agent = new Agent();
            agent.AgentID = int.Parse(txtAgentID.Text);
            int x = bll.DeleteAgent(agent);
            if (x > 0)
            {
                MessageBox.Show("Deleted");
            }
        }

        private void dgvAgent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvAgent.SelectedRows.Count > 0)
            {
                txtAgentID.Text = dgvAgent.SelectedRows[0].Cells["AgentID"].Value.ToString();
                txtName.Text = dgvAgent.SelectedRows[0].Cells["Name"].Value.ToString();
                txtSurname.Text = dgvAgent.SelectedRows[0].Cells["Surname"].Value.ToString();
                txtEmail.Text = dgvAgent.SelectedRows[0].Cells["Email"].Value.ToString();
                txtPassword.Text = dgvAgent.SelectedRows[0].Cells["Password"].Value.ToString();
                txtPhone.Text = dgvAgent.SelectedRows[0].Cells["Phone"].Value.ToString();
                cmbStatus.Text = dgvAgent.SelectedRows[0].Cells["Status"].Value.ToString();
                cmbAgencyID.Text = dgvAgent.SelectedRows[0].Cells["AgencyName"].Value.ToString();
            }
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
           frmAgentLogin Agent = new frmAgentLogin();
            Agent.Show();
            this.Hide();
        }
    }
}
