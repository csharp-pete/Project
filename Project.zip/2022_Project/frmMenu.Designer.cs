﻿namespace _2022_Project
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAdminLogin = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAgentLogin = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnTenantLogin = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnAdminLogin);
            this.panel1.Location = new System.Drawing.Point(34, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 289);
            this.panel1.TabIndex = 0;
            // 
            // btnAdminLogin
            // 
            this.btnAdminLogin.Location = new System.Drawing.Point(33, 115);
            this.btnAdminLogin.Name = "btnAdminLogin";
            this.btnAdminLogin.Size = new System.Drawing.Size(127, 80);
            this.btnAdminLogin.TabIndex = 0;
            this.btnAdminLogin.Text = "ADMIN LOGIN";
            this.btnAdminLogin.UseVisualStyleBackColor = true;
            this.btnAdminLogin.Click += new System.EventHandler(this.btnAdminLogin_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnAgentLogin);
            this.panel2.Location = new System.Drawing.Point(272, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 289);
            this.panel2.TabIndex = 1;
            // 
            // btnAgentLogin
            // 
            this.btnAgentLogin.Location = new System.Drawing.Point(28, 115);
            this.btnAgentLogin.Name = "btnAgentLogin";
            this.btnAgentLogin.Size = new System.Drawing.Size(127, 80);
            this.btnAgentLogin.TabIndex = 1;
            this.btnAgentLogin.Text = "AGENT LOGIN";
            this.btnAgentLogin.UseVisualStyleBackColor = true;
            this.btnAgentLogin.Click += new System.EventHandler(this.btnAgentLogin_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnTenantLogin);
            this.panel3.Location = new System.Drawing.Point(518, 23);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 289);
            this.panel3.TabIndex = 1;
            // 
            // btnTenantLogin
            // 
            this.btnTenantLogin.Location = new System.Drawing.Point(28, 115);
            this.btnTenantLogin.Name = "btnTenantLogin";
            this.btnTenantLogin.Size = new System.Drawing.Size(127, 80);
            this.btnTenantLogin.TabIndex = 2;
            this.btnTenantLogin.Text = "TENANT LOGIN";
            this.btnTenantLogin.UseVisualStyleBackColor = true;
            this.btnTenantLogin.Click += new System.EventHandler(this.btnTenantLogin_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 324);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "frmMenu";
            this.Text = "frmMenu";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAdminLogin;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnAgentLogin;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnTenantLogin;
    }
}