﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace _2022_Project
{
    public partial class frmRental : Form
    {
        public frmRental()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        private void frmRental_Load(object sender, EventArgs e)
        {
            txtRentalID.Enabled = false;

            cmbPropertyAgent.DataSource = bll.LoadcmbPropertyAgent();
            cmbPropertyAgent.DisplayMember = "PropertyAgentDate";
            cmbPropertyAgent.ValueMember = "PropertyAgentID";

            cmbTenantID.DataSource = bll.LoadcmbTenant();
            cmbTenantID.DisplayMember = "TenantInfo";
            cmbTenantID.ValueMember = "TenantID";

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Rental rental = new Rental();
            rental.PropertyAgent = int.Parse(cmbPropertyAgent.SelectedValue.ToString());
            rental.TenantID = int.Parse(cmbTenantID.SelectedValue.ToString());
            rental.StartDate = dtaStartDate.Text;
            rental.EndDate = dtaEndDate.Text;
            int x = bll.InsertRental(rental);
            if(x>0)
            {
                MessageBox.Show("Added");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            dgvRental.DataSource = bll.DisplayRental();
        }

        private void dgvRental_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dgvRental.SelectedRows.Count>0)
            {
                txtRentalID.Text = dgvRental.SelectedRows[0].Cells["RentalID"].Value.ToString();
                cmbPropertyAgent.Text = dgvRental.SelectedRows[0].Cells["Property Agent Date"].Value.ToString();
                cmbTenantID.Text = dgvRental.SelectedRows[0].Cells["TenantInfo"].Value.ToString();
                dtaStartDate.Text = dgvRental.SelectedRows[0].Cells["StartDate"].Value.ToString();
                dtaEndDate.Text = dgvRental.SelectedRows[0].Cells["EndDate"].Value.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Rental rental = new Rental();
            rental.RentalID = int.Parse(txtRentalID.Text);
            rental.StartDate = dtaStartDate.Text;
            rental.EndDate = dtaEndDate.Text;
            int x = bll.UpdateRental(rental);
            if (x > 0)
            {
                MessageBox.Show("Updated");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmAgentMenu menu = new frmAgentMenu();
            menu.Show();
            this.Hide();
        }
    }
}
