﻿namespace _2022_Project
{
    partial class frmMenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnProperties = new System.Windows.Forms.Button();
            this.btnPropertyTypes = new System.Windows.Forms.Button();
            this.btnLocation = new System.Windows.Forms.Button();
            this.btnAgents = new System.Windows.Forms.Button();
            this.btnAgencies = new System.Windows.Forms.Button();
            this.btnAddAdmin = new System.Windows.Forms.Button();
            this.btnSignOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(720, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADMIN";
            // 
            // btnProperties
            // 
            this.btnProperties.Location = new System.Drawing.Point(76, 110);
            this.btnProperties.Name = "btnProperties";
            this.btnProperties.Size = new System.Drawing.Size(182, 107);
            this.btnProperties.TabIndex = 1;
            this.btnProperties.Text = "PROPERTY";
            this.btnProperties.UseVisualStyleBackColor = true;
            this.btnProperties.Click += new System.EventHandler(this.btnProperties_Click);
            // 
            // btnPropertyTypes
            // 
            this.btnPropertyTypes.Location = new System.Drawing.Point(327, 110);
            this.btnPropertyTypes.Name = "btnPropertyTypes";
            this.btnPropertyTypes.Size = new System.Drawing.Size(182, 107);
            this.btnPropertyTypes.TabIndex = 2;
            this.btnPropertyTypes.Text = "PROPERTY TYPE";
            this.btnPropertyTypes.UseVisualStyleBackColor = true;
            this.btnPropertyTypes.Click += new System.EventHandler(this.btnPropertyTypes_Click);
            // 
            // btnLocation
            // 
            this.btnLocation.Location = new System.Drawing.Point(588, 110);
            this.btnLocation.Name = "btnLocation";
            this.btnLocation.Size = new System.Drawing.Size(182, 107);
            this.btnLocation.TabIndex = 3;
            this.btnLocation.Text = "LOCATION";
            this.btnLocation.UseVisualStyleBackColor = true;
            this.btnLocation.Click += new System.EventHandler(this.btnLocation_Click);
            // 
            // btnAgents
            // 
            this.btnAgents.Location = new System.Drawing.Point(327, 245);
            this.btnAgents.Name = "btnAgents";
            this.btnAgents.Size = new System.Drawing.Size(182, 107);
            this.btnAgents.TabIndex = 4;
            this.btnAgents.Text = "AGENTS";
            this.btnAgents.UseVisualStyleBackColor = true;
            this.btnAgents.Click += new System.EventHandler(this.btnAgents_Click);
            // 
            // btnAgencies
            // 
            this.btnAgencies.Location = new System.Drawing.Point(76, 245);
            this.btnAgencies.Name = "btnAgencies";
            this.btnAgencies.Size = new System.Drawing.Size(182, 107);
            this.btnAgencies.TabIndex = 5;
            this.btnAgencies.Text = "AGENCIES";
            this.btnAgencies.UseVisualStyleBackColor = true;
            this.btnAgencies.Click += new System.EventHandler(this.btnAgencies_Click);
            // 
            // btnAddAdmin
            // 
            this.btnAddAdmin.Location = new System.Drawing.Point(588, 245);
            this.btnAddAdmin.Name = "btnAddAdmin";
            this.btnAddAdmin.Size = new System.Drawing.Size(182, 107);
            this.btnAddAdmin.TabIndex = 6;
            this.btnAddAdmin.Text = "ADD ADMIN";
            this.btnAddAdmin.UseVisualStyleBackColor = true;
            this.btnAddAdmin.Click += new System.EventHandler(this.btnAddAdmin_Click);
            // 
            // btnSignOut
            // 
            this.btnSignOut.Location = new System.Drawing.Point(614, 395);
            this.btnSignOut.Name = "btnSignOut";
            this.btnSignOut.Size = new System.Drawing.Size(156, 36);
            this.btnSignOut.TabIndex = 7;
            this.btnSignOut.Text = "Sign out";
            this.btnSignOut.UseVisualStyleBackColor = true;
            this.btnSignOut.Click += new System.EventHandler(this.btnSignOut_Click);
            // 
            // frmMenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 489);
            this.Controls.Add(this.btnSignOut);
            this.Controls.Add(this.btnAddAdmin);
            this.Controls.Add(this.btnAgencies);
            this.Controls.Add(this.btnAgents);
            this.Controls.Add(this.btnLocation);
            this.Controls.Add(this.btnPropertyTypes);
            this.Controls.Add(this.btnProperties);
            this.Controls.Add(this.label1);
            this.Name = "frmMenuAdmin";
            this.Text = "frmMenuAdmin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnProperties;
        private System.Windows.Forms.Button btnPropertyTypes;
        private System.Windows.Forms.Button btnLocation;
        private System.Windows.Forms.Button btnAgents;
        private System.Windows.Forms.Button btnAgencies;
        private System.Windows.Forms.Button btnAddAdmin;
        private System.Windows.Forms.Button btnSignOut;
    }
}