﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class PropertyType
    {
        public int PropertyTypeID { get; set; }
        public string PropertyTypeDesc { get; set; }
         
    }
    public class Province
    {
        public int ProvinceID { get; set; }
        public string Description { get; set; }
    }
    public class City
    {
        public int CityID { get; set; }
        public string CityDescription { get; set; }
        public int ProvinceID { get; set; }
    }
    public class Surbub
    {
        public int SurbubID { get; set; }
        public string SurbubDescription { get; set; }
        public int PostalCode { get; set; }
        public int CityID { get; set; }
    }
    public class Agency
    {
        public int AgencyID { get; set; }
        public string AgencyName { get; set; }
        public int SurbubID { get; set; }
    }
    public class Agent
    {
        public int AgentID { get; set; }
        public int AgencyID { get; set; }
        public string AgentName { get; set; }
        public string AgentSurname { get; set; }
        public string AgentEmail { get; set; }
        public string Password { get; set; }
        public int Phone { get; set; }
        public string Status { get; set; }
    }
    public class Tenant
    {
        public int TenantID { get; set; }
        public string TenantName { get; set; }
        public string TenantSurname { get; set; }
        public string TenantEmail { get; set; }
        public string Password { get; set; }
        public int Phone { get; set; }
        public string Status { get; set; }
    }

    public class PropertyAgent
    {
        public int PropertyAgentID { get; set; }    
        public int PropertyID { get; set; } 
        public int AgentID { get; set; }    
        public string Date { get; set; }
    }

    public class Property
    {
        public int PropertyID { get; set; } 
        public string Description { get; set; } 
        public double Price { get; set; }   
        public byte[] Image { get; set; }   
        public int PropertyTypeID { get; set; } 
        public string Status { get; set; }
        public int SurbubID { get; set; }   
    }
    public class Rental
    {
        public int RentalID { get; set; }
        public int PropertyAgent { get; set; }
        public int TenantID { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
    public class Login
    {
        public int LoginID { get; set; }
    }
    public class User
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserSurname { get; set; }
        public string UserEmail { get; set; }
        public string UserPassword { get; set; }
        public int RoleID { get; set; }
    }
    public class GetAdminLogin
    {
        public string Email { get; set; }
        public string Password { get; set; }    
    }
    public class GetAgentLogin
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
    public class GetTenantLogin
    {
        public string Email
        {
            get; set;
        }
        public string Password
        {
            get; set;
        }
    } 
    public class Administrator
    {
        public int AdminID { get; set; }
        public string Name { get; set; }    
        public string Surname { get; set; } 
        public string Email { get; set; }
        public string Password { get; set; }
        public string Status { get; set; }

    }
}
