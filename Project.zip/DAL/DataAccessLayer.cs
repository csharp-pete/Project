﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class DataAccessLayer
    {
        static string connString = "Data Source = localhost; Initial Catalog = ProjectDB; Integrated Security = true;";
        SqlConnection dbConn = new SqlConnection(connString);
        SqlCommand dbComm;
        SqlDataAdapter dbAdapter;
        DataTable dt;

        public int InsertPropertyType(PropertyType propType)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertPropertyType", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@PropertyTypeDescription", propType.PropertyTypeDesc);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable DisplayPropertyType()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayPropertyType", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int InsertProvince(Province p)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertProvince", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@Description", p.Description);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
                
        }
        public DataTable DisplayProvince()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayProvince", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int InsertCity(City c)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertCity", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@CityDescription", c.CityDescription);
            dbComm.Parameters.AddWithValue("@ProvinceID", c.ProvinceID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable DisplayCity()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayCity", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable LoadcmbProvince()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadcmbProvince", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int InsertSurbub(Surbub surbub)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertSurbub", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@SurbubDescription", surbub.SurbubDescription);
            dbComm.Parameters.AddWithValue("@PostalCode", surbub.PostalCode);
            dbComm.Parameters.AddWithValue("@CityID", surbub.CityID);


            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable DisplaySurbub()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplaySurbub", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable LoadcmbCity()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadcmbCity", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int InsertAgency (Agency agency)
        {

            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertAgency", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@AgencyName", agency.AgencyName);
            dbComm.Parameters.AddWithValue("@SurbubID", agency.SurbubID);


            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable DisplayAgency()
        {

            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayAgency", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable LoadcmbSurbub()
        {

            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadcmbSurbub", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int DeleteAgency(Agency agency)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DeleteAgency", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@AgencyID", agency.AgencyID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int InsertAgent(Agent agent)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("Name", agent.AgentName);
            dbComm.Parameters.AddWithValue("Surname", agent.AgentSurname);
            dbComm.Parameters.AddWithValue("Email", agent.AgentEmail);
            dbComm.Parameters.AddWithValue("Password", agent.Password);
            dbComm.Parameters.AddWithValue("Phone", agent.Phone);
            dbComm.Parameters.AddWithValue("Status", agent.Status);
            dbComm.Parameters.AddWithValue("AgencyID", agent.AgencyID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable DisplayAgent()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateAgent(Agent agent)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_UpdateAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("Email", agent.AgentEmail);
            dbComm.Parameters.AddWithValue("Phone", agent.Phone);
            dbComm.Parameters.AddWithValue("Status", agent.Status);
            dbComm.Parameters.AddWithValue("AgentID", agent.AgentID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable LoadcmbAgency()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadcmbAgency", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int DeleteAgent(Agent agent)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DeleteAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("AgentID", agent.AgentID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int InsertTenant(Tenant tenant)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertTenant", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("Name", tenant.TenantName);
            dbComm.Parameters.AddWithValue("Surname", tenant.TenantSurname);
            dbComm.Parameters.AddWithValue("Email", tenant.TenantEmail);
            dbComm.Parameters.AddWithValue("Password", tenant.Password);
            dbComm.Parameters.AddWithValue("Phone", tenant.Phone);
            dbComm.Parameters.AddWithValue("Status", tenant.Status);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int UpdateTenant(Tenant tenant)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_UpdateTenant", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("Email", tenant.TenantEmail);
            dbComm.Parameters.AddWithValue("Phone", tenant.Phone);
            dbComm.Parameters.AddWithValue("Status", tenant.Status);
            dbComm.Parameters.AddWithValue("TenantID", tenant.TenantID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int DeleteTenant(Tenant tenant)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DeleteTenant", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("TenantID", tenant.TenantID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable DisplayTenant()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayTenant", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }

        public int InsertPropertyAgent(PropertyAgent pagent)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertPropertyAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("PropertyID", pagent.PropertyID);
            dbComm.Parameters.AddWithValue("AgentID", pagent.AgentID);
            dbComm.Parameters.AddWithValue("Date", pagent.Date);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public int UpdatePropertyAgent(PropertyAgent pagent)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_UpdatePropertyAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("PropertyAgentID", pagent.PropertyAgentID);
            dbComm.Parameters.AddWithValue("PropertyID", pagent.PropertyID);
            dbComm.Parameters.AddWithValue("AgentID", pagent.AgentID);
            dbComm.Parameters.AddWithValue("Date", pagent.Date);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public DataTable DisplayPropertyAgent()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayPropertyAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }

        public DataTable LoadAgent()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }

        public int InsertProperty(Property property)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("Description", property.Description);
            dbComm.Parameters.AddWithValue("Price", property.Price);
            dbComm.Parameters.AddWithValue("Image", property.Image);
            dbComm.Parameters.AddWithValue("PropertyTypeID", property.PropertyTypeID);
            dbComm.Parameters.AddWithValue("Status", property.Status);
            dbComm.Parameters.AddWithValue("SurbubID", property.SurbubID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public DataTable DisplayProperty()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }

        public int UpdateProperty(Property property)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_UpdateProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("PropertyID", property.PropertyID);
            dbComm.Parameters.AddWithValue("Price", property.Price);
            dbComm.Parameters.AddWithValue("PropertyTypeID", property.PropertyTypeID);
            dbComm.Parameters.AddWithValue("Status", property.Status);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public int DeleteProperty(Property property)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DeleteProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("PropertyID", property.PropertyID);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public DataTable LoadPropertyType()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadPropertyType", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable LoadcmbProperty()
        {

            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadcmbProperty", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int InsertRental(Rental rental)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertRental", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("PropertyAgentID", rental.PropertyAgent);
            dbComm.Parameters.AddWithValue("TenantID", rental.TenantID);
            dbComm.Parameters.AddWithValue("StartDate", rental.StartDate);
            dbComm.Parameters.AddWithValue("EndDate", rental.EndDate);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int UpdateRental(Rental rental)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_UpdateRental", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("RentalID", rental.RentalID);
            dbComm.Parameters.AddWithValue("StartDate", rental.StartDate);
            dbComm.Parameters.AddWithValue("EndDate", rental.EndDate);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable DisplayRental()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayRental", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable LoadcmbPropertyAgent()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadcmbPropertyAgent", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable LoadcmbTenant()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_LoadcmbTenant", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable GetAdminLogin(string email, string password)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_GetAdminLogin", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("Email", email);
            dbComm.Parameters.AddWithValue("Password", password);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable GetAgentLogin(string email, string password)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_GetAgentLogin", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@Email", email);
            dbComm.Parameters.AddWithValue("@Password", password);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable GetTenantLogin(string email, string password)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_GetTenantLogin", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@Email", email);
            dbComm.Parameters.AddWithValue("@Password", password);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int InsertAdmin(Administrator admin)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_InsertAdmin",dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("Name",admin.Name);
            dbComm.Parameters.AddWithValue("Surname", admin.Surname);
            dbComm.Parameters.AddWithValue("Email", admin.Email);
            dbComm.Parameters.AddWithValue("Password", admin.Password);
            dbComm.Parameters.AddWithValue("Status", admin.Status);
            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;


        }
        public DataTable DisplayAdmin()
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_DisplayAdmin", dbConn);
            dbComm.CommandType= CommandType.StoredProcedure;
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public DataTable GetAgentReport(string description, string start, string end)
        {
            dbConn.Open();
            dbComm = new SqlCommand("sp_GetAgentReport", dbConn);
            dbComm.CommandType = CommandType.StoredProcedure;
            dbComm.Parameters.AddWithValue("@Description", description);
            dbComm.Parameters.AddWithValue("@StartDate", start);
            dbComm.Parameters.AddWithValue("@EndDate", end);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }

    }

}
