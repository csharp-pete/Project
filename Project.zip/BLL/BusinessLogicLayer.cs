﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DAL;

namespace BLL
{
    public class BusinessLogicLayer
    {
        DataAccessLayer dal = new DataAccessLayer();
        public int InsertPropertyType(PropertyType propType)
        {
            return dal.InsertPropertyType(propType);
        }
        public DataTable DisplayPropertyType()
        {
            return dal.DisplayPropertyType();
        }
        public int InsertProvince(Province p)
        {
            return dal.InsertProvince(p);
        }
        public DataTable DisplayProvince()
        {
            return dal.DisplayProvince();
        }
        public int InsertCity(City c)
        {
            return dal.InsertCity(c);
        }
        public DataTable DisplayCity()
        {
            return dal.DisplayCity();
        }
        public DataTable LoadcmbProvince()
        {
            return dal.LoadcmbProvince();
        }
        public int InsertSurbub(Surbub surbub)
        {
            return dal.InsertSurbub(surbub);
        }
        public DataTable DisplaySurbub()
        {
            return dal.DisplaySurbub();

        }
        public DataTable LoadcmbCity()
        {
            return dal.LoadcmbCity();
        }
        public int InsertAgency(Agency agency)
        {
            return dal.InsertAgency(agency);
        }
        public DataTable DisplayAgency()
        {
            return dal.DisplayAgency();
        }
        public DataTable LoadcmbSurbub()
        {
            return dal.LoadcmbSurbub();
        }
        public int DeleteAgency(Agency agency)
        {
            return dal.DeleteAgency(agency);    
        }
        public int InsertAgent(Agent agent)
        {
            return dal.InsertAgent(agent);
        }
        public int UpdateAgent(Agent agent)
        {
            return dal.UpdateAgent(agent);
        }
        public int DeleteAgent(Agent agent)
        {
            return dal.DeleteAgent(agent);
        }
        public DataTable DisplayAgent()
        {
            return dal.DisplayAgent();
        }
        public DataTable LoadcmbAgency()
        {
            return dal.LoadcmbAgency();
        }
        public int InsertTenant(Tenant tenant)
        {
            return dal.InsertTenant(tenant);
        }
        public int UpdateTenant(Tenant tenant)
        {
            return dal.UpdateTenant(tenant);    
        }
        public int DeleteTenant(Tenant tenant)
        {
            return dal.DeleteTenant(tenant);
        }
        public DataTable DisplayTenant()
        {
            return dal.DisplayTenant();
        }
        public int InsertPropertyAgent(PropertyAgent pagent)
        {
            return dal.InsertPropertyAgent(pagent);
        }
        public int UpdatePropertyAgent(PropertyAgent pagent)
        {
            return dal.UpdatePropertyAgent(pagent);
        }
        public DataTable DisplayPropertyAgent()
        {
            return dal.DisplayPropertyAgent();
        }
        public DataTable LoadAgent()
        {
            return dal.LoadAgent(); 
        }

        public int InsertProperty(Property property)
        {
            return dal.InsertProperty(property);
        }

        public int UpdateProperty(Property property)
        {
            return dal.UpdateProperty(property);
        }

        public int DeleteProperty(Property property)
        {
            return dal.DeleteProperty(property);    
        }

        public DataTable DisplayProperty()
        {
            return dal.DisplayProperty();
        }

        public DataTable LoadPropertyType()
        {
            return dal.LoadPropertyType();

        }
        public DataTable LoadcmbProperty()
        {
            return dal.LoadcmbProperty();
        }
        public int InsertRental(Rental rental)
        {
            return dal.InsertRental(rental);
        }
        public int UpdateRental(Rental rental)
        {
            return dal.UpdateRental(rental);
        }
        public DataTable DisplayRental()
        {
            return dal.DisplayRental();
        }
        public DataTable LoadcmbPropertyAgent()
        {
            return dal.LoadcmbPropertyAgent();
        }
        public DataTable LoadcmbTenant()
        {
            return dal.LoadcmbTenant();
        }
        //public DataTable Logins(string email, string password)
        //{

        //    return dal.Logins(email, password);
        //}
        public DataTable GetAdminLogin(string email, string password)
        {
            return dal.GetAdminLogin(email, password);
        }
        public DataTable GetAgentLogin(string email, string password)
        {
            return dal.GetAgentLogin(email, password);
        }
        public DataTable GetTenantLogin(string email, string password)
        {
            return dal.GetTenantLogin(email, password);
        }
        public int InsertAdmin(Administrator admin)
        {
            return dal.InsertAdmin(admin);
        }
        public DataTable DisplayAdmin()
        {
            return dal.DisplayAdmin();
        }
        public DataTable GetAgentReport(string description, string start, string end)
        {
            return dal.GetAgentReport(description, start, end);
        }
    }
}
